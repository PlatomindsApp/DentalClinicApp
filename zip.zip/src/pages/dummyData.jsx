export const doctors = [
    {
      id: 1,
      name: "Dr. John Doe",
      specialty: "General Dentistry",
      location: "New York, NY",
      contact: "123-456-7890"
    },
    {
      id: 2,
      name: "Dr. Jane Smith",
      specialty: "Orthodontics",
      location: "Los Angeles, CA",
      contact: "987-654-3210"
    },
    // Add more doctors as needed
  ];