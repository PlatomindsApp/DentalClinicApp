/* eslint-disable no-unused-vars */
import React from 'react'

function FaQs() {
  return (
    <div>
      <h1>faqs</h1>
    </div>
  )
}

export default FaQs
