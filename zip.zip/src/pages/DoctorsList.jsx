/* eslint-disable no-unused-vars */
import React from 'react'

function DoctorsList() {
  return (
    <div>
      <h1>doctors list</h1>
    </div>
  )
}

export default DoctorsList
