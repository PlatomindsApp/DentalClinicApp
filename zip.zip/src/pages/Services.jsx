/* eslint-disable no-unused-vars */
import React from 'react'

function Services() {
  return (
    <div>
      <h1>services</h1>
    </div>
  )
}

export default Services
