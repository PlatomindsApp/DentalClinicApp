/* eslint-disable no-unused-vars */
import React from 'react'

function AboutUs() {
  return (
    <div>
   <h1>about us</h1>   
    </div>
  )
}

export default AboutUs
